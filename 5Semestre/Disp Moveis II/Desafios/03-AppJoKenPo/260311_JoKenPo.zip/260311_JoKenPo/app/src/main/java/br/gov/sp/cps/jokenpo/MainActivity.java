package br.gov.sp.cps.jokenpo;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private int pontosJogador = 0;
    private int pontosPC = 0;
    private TextView textPlacar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textPlacar = findViewById(R.id.textPlacar);
        atualizarPlacar(); // Inicializa placar com 0x0
    }

    // Selecionado Pedra
    public void selecPedra(View view){
        opcaoSelecionada("pedra");
    }

    // Selecionado Papel
    public void selecPapel(View view){
        opcaoSelecionada("papel");
    }

    // Selecionado Tesoura
    public void selecTesoura(View view){
        opcaoSelecionada("tesoura");
    }

    // Analisa jogada e atualiza placar
    public void opcaoSelecionada(String opcaoSelecionada) {
        ImageView imgResultado = findViewById(R.id.imgResultado);
        TextView textResultado = findViewById(R.id.textResultado);

        // Escolha do PC
        int numero = new Random().nextInt(3);
        String[] opcoes = {"pedra", "papel", "tesoura"};
        String opcaoPC = opcoes[numero];

        // Atualiza imagem do PC
        switch (opcaoPC) {
            case "pedra": imgResultado.setImageResource(R.drawable.pedra); break;
            case "papel": imgResultado.setImageResource(R.drawable.papel); break;
            case "tesoura": imgResultado.setImageResource(R.drawable.tesoura); break;
        }

        // Lógica do jogo
        if ((opcaoSelecionada.equals("tesoura") && opcaoPC.equals("papel")) ||
                (opcaoSelecionada.equals("papel") && opcaoPC.equals("pedra")) ||
                (opcaoSelecionada.equals("pedra") && opcaoPC.equals("tesoura"))) {
            pontosJogador++;
            textResultado.setText("Você ganhou esta rodada!");
        } else if ((opcaoPC.equals("tesoura") && opcaoSelecionada.equals("papel")) ||
                (opcaoPC.equals("papel") && opcaoSelecionada.equals("pedra")) ||
                (opcaoPC.equals("pedra") && opcaoSelecionada.equals("tesoura"))) {
            pontosPC++;
            textResultado.setText("PC ganhou esta rodada!");
        } else {
            textResultado.setText("Empate!");
        }

        // Atualiza placar
        atualizarPlacar();

        // Verifica melhor de 5 e reseta automaticamente
        if (pontosJogador == 3) {
            textResultado.setText("🎉 Você venceu a melhor de 5! 🎉");
            resetarContadores();
        } else if (pontosPC == 3) {
            textResultado.setText("💻 PC venceu a melhor de 5! 💻");
            resetarContadores();
        }
    }

    // Atualiza placar permanente
    private void atualizarPlacar() {
        textPlacar.setText("PC [ " + pontosPC + " ] x [ " + pontosJogador + " ] Você");
    }

    // Reseta contadores sem alterar imagens/texto principal
    private void resetarContadores() {
        pontosJogador = 0;
        pontosPC = 0;
        atualizarPlacar();
    }

    // Reset manual
    public void resetarJogo(View view) {
        resetarContadores();
        TextView textResultado = findViewById(R.id.textResultado);
        textResultado.setText("Escolha sua opção:");
        ImageView imgResultado = findViewById(R.id.imgResultado);
        imgResultado.setImageResource(R.drawable.padrao);
    }
}