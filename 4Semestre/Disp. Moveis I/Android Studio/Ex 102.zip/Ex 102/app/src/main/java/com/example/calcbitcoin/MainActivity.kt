package com.example.calcbitcoin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.* // Para Button, EditText, TextView
import java.net.URL
import org.json.JSONObject
import java.text.NumberFormat
import java.util.*

// Imports de Coroutines (Método moderno, substitui doAsync/uiThread)
import kotlinx.coroutines.*
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.Dispatchers.Main

class MainActivity : AppCompatActivity() {

    val API_URL = "https://www.mercadobitcoin.net/api/BTC/ticker/"
    var cotacaoBitcoin: Double = 0.0

    // Declaração das Views como lateinit (substitui imports sintéticos)
    private lateinit var btnCalcular: Button
    private lateinit var txtValor: EditText
    private lateinit var txtCotacao: TextView
    private lateinit var txtQtdBitcoins: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // *** Inicialização das Views (Substitui os imports sintéticos descontinuados) ***
        // Nota: Garanta que estes IDs (R.id.txtValor, R.id.btnCalcular, etc.)
        // estejam corretos no seu arquivo de layout XML.
        txtValor = findViewById(R.id.txtValor)
        btnCalcular = findViewById(R.id.btnCalcular)
        txtCotacao = findViewById(R.id.txtCotacao)
        txtQtdBitcoins = findViewById(R.id.txtQtdBitcoins)
        // ********************************************************************************

        buscarCotacao()

        // listener do botão calcular
        btnCalcular.setOnClickListener {
            calcular()
        }
    }

    fun buscarCotacao() {
        // Usando Coroutines para operações de rede (melhor prática moderna)
        GlobalScope.launch(IO) {
            try {
                // Acessar a API e buscar seu resultado
                val resposta = URL(API_URL).readText()
                cotacaoBitcoin = JSONObject(resposta).getJSONObject("ticker").getDouble("last")

                // Formatação da moeda (pt-BR)
                val f = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
                val cotacaoFormatada = f.format(cotacaoBitcoin)

                // Atualizar a UI na Thread Principal
                withContext(Main) {
                    txtCotacao.text = cotacaoFormatada
                }
            } catch (e: Exception) {
                // Lidar com erros de rede
                e.printStackTrace()
                withContext(Main) {
                    // Usando Toast em vez de alert, que requer a biblioteca Anko completa
                    Toast.makeText(this@MainActivity, "Erro ao buscar cotação.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun calcular() {
        if (txtValor.text.isEmpty()) {
            txtValor.error = "Preencha um valor"
            return
        }
        // valor digitado pelo usuário
        val valorDigitado = txtValor.text.toString().replace(",", ".").toDouble()

        // caso não venha valor da API
        val resultado = if (cotacaoBitcoin > 0) valorDigitado / cotacaoBitcoin
        else 0.0

        // atualizando o TextView com o resultado formatado com 8 casas decimais
        txtQtdBitcoins.text = "%.8f".format(resultado)
    }
}